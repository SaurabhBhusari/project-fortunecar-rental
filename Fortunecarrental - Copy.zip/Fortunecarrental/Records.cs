﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fortunecarrental
{
    public partial class Records : Form
    {
        public Records()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            carcrp rcr = new carcrp();
            rcr.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintan rcr = new maintan();
            rcr.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            customercrp rcr = new customercrp();
            rcr.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            rentalcp rcr = new rentalcp();
            rcr.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            returncrp rcr = new returncrp();
            rcr.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            usercrp rcr = new usercrp();
            rcr.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMain main = new FortuneMain();
            main.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
