﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class rentalcp : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

        public rentalcp()
        {
            InitializeComponent();
        }

        private void rentalcp_Load(object sender, EventArgs e)
        {
             

      
            DataSet dt = new DataSet();
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from RentalTb1", Con);

            sda.Fill(dt, "RentalTb1");

           // Con.Close();
            rentalCrystalReport1 rcr = new rentalCrystalReport1();
            rcr.SetDataSource(dt.Tables["RentalTb1"]);
            crystalReportViewer1.ReportSource = null;
            crystalReportViewer1.ReportSource = rcr;
           // crystalReportViewer1.Show();
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Rental rental = new Rental();
            rental.Show();
        }
    }
}
