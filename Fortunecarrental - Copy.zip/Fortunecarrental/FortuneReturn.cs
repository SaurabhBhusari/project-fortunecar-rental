﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class FortuneReturn : Form
    {
        
        
        public FortuneReturn()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");


        private void CustNameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void RentDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Custcb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void CarRegCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FeesTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void ReturnDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void IdTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMain main = new FortuneMain();
            main.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (IdTb.Text == "" || CarIdTb.Text == "" || CustNameTb.Text == "" || ReturnDate.Text == "" || DelayTb.Text == "" || FineTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "update ReturnTb1 set CarReg='" + CarIdTb.Text + "', CustName='" + CustNameTb.Text + "',Delay=" + DelayTb.Text + " ,Fine='" + FineTb.Text + "' ,ReturnDate=" + ReturnDate.Text + " where  Returnid='" + IdTb.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Data Suscessfully Updated");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (IdTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "Delete From ReturnTb1 where Returnid='" + IdTb.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(" Data Deleted Suscessfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (IdTb.Text == "" || CustNameTb.Text == "" || FineTb.Text == "" || DelayTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into ReturnTb1 values(" + IdTb.Text + ",'"+CarIdTb.Text+"','" + CustNameTb.Text + "', '" + ReturnDate.Text + "', '" + DelayTb.Text + "'," + FineTb.Text + ")";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Returned");
                    Con.Close();
                    populate1();
                    Deleteconreturn();
                    UpadateconRentDelete();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void FortuneRentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void populate()
        {
            Con.Open();
            string query = "select * from RentalTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FortuneRentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void populate1()
        {
            Con.Open();
            string query = "select * from ReturnTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            ReturnDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Deleteconreturn()
        {
            int rentId;
            rentId =Convert.ToInt32(FortuneRentDGV.SelectedRows[0].Cells[0].Value.ToString());
            Con.Open();
            string query = "Delete From RentalTb1 where Rentid =" + rentId + ";";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            Con.Close();
            populate();
            
        }

        private void FortuneReturn_Load(object sender, EventArgs e)
        {
            populate();
            populate1();
            
        }
         private void UpadateconRentDelete()
         {

             Con.Open();
             string query = "update CarTb1 set Available='" + "Yes" + "' where RegNo = '" + CarIdTb.Text + "';";
             SqlCommand cmd = new SqlCommand(query, Con);
             cmd.ExecuteNonQuery();
             Con.Close();


         }

        private void gunaDataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            IdTb.Text = ReturnDGV.SelectedRows[0].Cells[0].Value.ToString();
            CarIdTb.Text = ReturnDGV.SelectedRows[0].Cells[1].Value.ToString();
            CustNameTb.Text = ReturnDGV.SelectedRows[0].Cells[2].Value.ToString();
            ReturnDate.Text = ReturnDGV.SelectedRows[0].Cells[3].Value.ToString();
            DelayTb.Text = ReturnDGV.SelectedRows[0].Cells[4].Value.ToString();
            FineTb.Text = ReturnDGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void FortuneRentDGV_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            CarIdTb.Text = FortuneRentDGV.SelectedRows[0].Cells[1].Value.ToString();
            CustNameTb.Text = FortuneRentDGV.SelectedRows[0].Cells[2].Value.ToString();
            ReturnDate.Text = FortuneRentDGV.SelectedRows[0].Cells[4].Value.ToString();
            DateTime d1 = ReturnDate.Value.Date;
            DateTime d2 = DateTime.Now;
            TimeSpan t = d2 - d1;
            int NrOfDays = Convert.ToInt32(t.TotalDays);
            if (NrOfDays <= 0)
            {
                DelayTb.Text = "No Delay";
                FineTb.Text = "0";
            }
            else 
            {
                DelayTb.Text = "" + NrOfDays;
                FineTb.Text = "" + (NrOfDays * 250);
            }
            
        }
        

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            printDocument1.Print();
                
        }

        private void PREVIEWTb_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            e.Graphics.DrawString("FORTUNE CAR RENTAL", new Font("Microsoft Sans Serif", 28, FontStyle.Bold), Brushes.Red, new Point(250, 50));
            e.Graphics.DrawString("NEAR SGM COLLEGE, KARAD ,VIDYANAGAR,KARAD", new Font("Microsoft Sans Serif", 15, FontStyle.Regular), Brushes.Black, new Point(230, 150));
            e.Graphics.DrawString("DATE"+DateTime.Now, new Font("Microsoft Sans Serif", 13, FontStyle.Regular), Brushes.Black, new Point(0, 130));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 170));
            e.Graphics.DrawString("INFORMATION", new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(0, 200));
            e.Graphics.DrawString("CUSTOMER NAME " , new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(200, 220));
            e.Graphics.DrawString(CustNameTb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(220, 250));
            e.Graphics.DrawString("CAR ID", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(500, 220));
            e.Graphics.DrawString(CarIdTb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(520, 250));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 290));
            e.Graphics.DrawString("Amount", new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(0, 320));
            e.Graphics.DrawString("DELAY IN DAYS ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(200, 340));
            e.Graphics.DrawString(DelayTb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(220, 370));
            e.Graphics.DrawString("FINE", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(500, 340));
            e.Graphics.DrawString(FineTb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(520, 370));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 410));
            e.Graphics.DrawString("STAMP ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(150, 960));
            e.Graphics.DrawString("SIGNATURE ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(600, 960));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 1000));
            
        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            this.Hide();
            returncrp rcr = new returncrp();
            rcr.Show();
        }
    }
}
