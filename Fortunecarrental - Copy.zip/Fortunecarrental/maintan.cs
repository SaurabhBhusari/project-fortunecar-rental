﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class maintan : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        
        public maintan()
        {
            InitializeComponent();
        }

        private void maintan_Load(object sender, EventArgs e)
        {
            DataSet dt = new DataSet();
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from MainTb1", Con);

            sda.Fill(dt, "MainTb1");

            // Con.Close();
            CrystalReport1 rcr = new CrystalReport1();
            rcr.SetDataSource(dt.Tables["MainTb1"]);
            crystalReportViewer1.ReportSource = null;
            crystalReportViewer1.ReportSource = rcr;
            // crystalReportViewer1.Show();
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMaintance maint = new FortuneMaintance();
            maint.Show();
        }
    }
}
