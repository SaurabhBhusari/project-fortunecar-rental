﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class Fortunelogin : Form
    {
        public Fortunelogin()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        

        private void gunaCirclePictureBox1_Click(object sender, EventArgs e)
        {
           
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Uname.Text = "";
            Upass.Text = "";
        }

        private void gunaCircleButton1_Click(object sender, EventArgs e)
        {
            string query = "Select count(*)from UserTb1 where Uname = '" + Uname.Text + "'and Upass = '" + Upass.Text + "'";
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {

                FortuneMain main = new FortuneMain();
                main.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("WRONG USERNAME AND PASSWORD");
            }


            Con.Close();
        }

        private void Uname_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
 