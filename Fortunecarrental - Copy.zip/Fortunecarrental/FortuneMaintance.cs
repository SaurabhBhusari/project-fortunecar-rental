﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Fortunecarrental
{
    public partial class FortuneMaintance : Form
    {
        public FortuneMaintance()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

        private void populate()
        {
            Con.Open();
            string query = "select * from CarTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FortuneCarDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void populate1()
        {
            Con.Open();
            string query = "select * from MainTb1";
            SqlDataAdapter da = new SqlDataAdapter(query,Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            MainDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void UpadateconRentDelete()
        {

            Con.Open();
            string query = "update CarTb1 set Available='" + "Yes" + "' where RegNo = '" + RegNoTb.Text + "';";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Car Data Suscessfully Updated");
            Con.Close();


        }

        private void UpadateconRentAdd()
        {

            Con.Open();
            string query = "update CarTb1 set Available='" + "No" + "' where RegNo = '" + RegNoTb.Text + "';";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Car Data Suscessfully Updated");
            Con.Close();


        }
        
      /*  private void DeleteconMain()
        {
           // int rentId;
         //  rentId = Convert.ToInt32(FortuneCarDGV.SelectedRows[0].Cells[0].Value.ToString());
            Con.Open();
            string query = "Delete From CarTb1 where RegNo =" + RegNoTb + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            MessageBox.Show("Rental Deleted Suscessfully");
           // cmd.ExecuteNonQuery();
           // MessageBox.Show("Rental Deleted Suscessfully");
            Con.Close();
            populate1();
            //UpadateconRentDelete();
        }*/

        private void FortuneCarDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RegNoTb.Text = FortuneCarDGV.SelectedRows[0].Cells[0].Value.ToString();
            BrandTb.Text = FortuneCarDGV.SelectedRows[0].Cells[1].Value.ToString();
            ModelTb.Text = FortuneCarDGV.SelectedRows[0].Cells[2].Value.ToString();
        }

        private void FortuneMaintance_Load(object sender, EventArgs e)
        {
            populate();
            populate1();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneCar car = new FortuneCar();
            car.Show();
        }

        private void MainDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RegNoTb.Text = MainDGV.SelectedRows[0].Cells[0].Value.ToString();
            BrandTb.Text = MainDGV.SelectedRows[0].Cells[1].Value.ToString();
            ModelTb.Text = MainDGV.SelectedRows[0].Cells[2].Value.ToString();
            MCostTb.Text = MainDGV.SelectedRows[0].Cells[3].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (RegNoTb.Text == "" || BrandTb.Text == "" || ModelTb.Text == "" || MCostTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into MainTb1 values('" + RegNoTb.Text + "','" + BrandTb.Text + "','" + ModelTb.Text + "','" + MCostTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Maintenance Suscessfully Added");
                    Con.Close();
                    populate1();
                    UpadateconRentAdd();
                    //DeleteconMain();
                }

                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (RegNoTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "Delete From MainTb1 where RegNo='" + RegNoTb.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Maintenace Data Deleted Suscessfully");
                    Con.Close();
                    populate1();
                    UpadateconRentDelete();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            maintan rcr = new maintan();
            rcr.Show();
        }
    }
}
