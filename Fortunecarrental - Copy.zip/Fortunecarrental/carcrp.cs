﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class carcrp : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        
        public carcrp()
        {
            InitializeComponent();
        }

        private void carcrp_Load(object sender, EventArgs e)
        {
            DataSet dt = new DataSet();
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from CarTb1", Con);

            sda.Fill(dt, "CarTb1");

            // Con.Close();
            carCrystalReport1 rcr = new carCrystalReport1();
            rcr.SetDataSource(dt.Tables["CarTb1"]);
            crystalReportViewer1.ReportSource = null;
            crystalReportViewer1.ReportSource = rcr;
            // crystalReportViewer1.Show();
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneCar car = new FortuneCar();
            car.Show();
        }
    }
}
