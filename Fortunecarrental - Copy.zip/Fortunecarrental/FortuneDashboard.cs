﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;


namespace Fortunecarrental
{
    public partial class FortuneDashboard : Form
    {
        public FortuneDashboard()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");


        private void FortuneDashboard_Load(object sender, EventArgs e)
        {
            String querycar = "select count(*) from CarTb1";
            SqlDataAdapter sda = new SqlDataAdapter(querycar, Con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CarLb1.Text = dt.Rows[0][0].ToString();
            
            String querycust = "select count(*) from CustomerTb1";
            SqlDataAdapter sda1 = new SqlDataAdapter(querycust, Con);
            DataTable dt1 = new DataTable();
            sda1.Fill(dt1);
            CustLb1.Text = dt1.Rows[0][0].ToString();

            String queryUser = "select count(*) from UserTb1";
            SqlDataAdapter sda2 = new SqlDataAdapter(queryUser, Con);
            DataTable dt2 = new DataTable();
            sda2.Fill(dt2);
            UserLb1.Text = dt2.Rows[0][0].ToString();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CarLb1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMain main = new FortuneMain();
            main.Show();
        }

        private void CustLb1_Click(object sender, EventArgs e)
        {

        }
    }
}
