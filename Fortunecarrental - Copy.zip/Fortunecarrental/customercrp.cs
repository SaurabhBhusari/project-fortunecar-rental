﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class customercrp : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        
        public customercrp()
        {
            InitializeComponent();
        }

        private void customercrp_Load(object sender, EventArgs e)
        {
            DataSet dt = new DataSet();
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from CustomerTb1", Con);

            sda.Fill(dt, "CustomerTb1");

            // Con.Close();
            customerCrystalReport2 rcr = new customerCrystalReport2();
            rcr.SetDataSource(dt.Tables["CustomerTb1"]);
            crystalReportViewer1.ReportSource = null;
            crystalReportViewer1.ReportSource = rcr;
            // crystalReportViewer1.Show();
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneCustomer customer = new FortuneCustomer();
            customer.Show();
        }
    }
}
