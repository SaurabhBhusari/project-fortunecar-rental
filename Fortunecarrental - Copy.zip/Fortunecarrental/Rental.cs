﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class Rental : Form
    {
        public Rental()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

        private void fillcombo()
        {
            Con.Open();
            string query = "select  RegNo from CarTb1 where Available='"+"Yes"+"'";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("RegNo", typeof(string));
            dt.Load(rdr);
            CarRegCb.ValueMember = "RegNo";
            CarRegCb.DataSource = dt;
            Con.Close();
        }
        private void fillCustomer()
        {
            Con.Open();
            string query = "select  Custid from CustomerTb1";
            SqlCommand cmd = new SqlCommand(query, Con);
            SqlDataReader rdr;
            rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("Custid", typeof(int));
            dt.Load(rdr);
            Custcb.ValueMember = "Custid";
            Custcb.DataSource = dt;
            Con.Close();
        }
        private void fetchCustName()
        {
            Con.Open();
            string query = "select * from CustomerTb1 where Custid=" + Custcb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(query, Con);
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                CustNameTb.Text = dr["CustName"].ToString();
                
            }

            Con.Close();
 
        }
         
        private void populate()
        {
            Con.Open();
            string query = "select * from RentalTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FortuneRentDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void populate1()
        {
            Con.Open();
            string query = "select * from CarTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            CarDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void UpadateconRent()
        {
            
                    Con.Open();
                    string query = "update CarTb1 set Available='" + "No" +  "' where RegNo = '" + CarRegCb.SelectedValue.ToString() + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                   // MessageBox.Show("Car Data Suscessfully Updated");
                    Con.Close();
                   
 
        }
        private void UpadateconRentDelete()
        {

            Con.Open();
            string query = "update CarTb1 set Available='" + "Yes" + "' where RegNo = '" + CarRegCb.SelectedValue.ToString() + "';";
            SqlCommand cmd = new SqlCommand(query, Con);
            cmd.ExecuteNonQuery();
            // MessageBox.Show("Car Data Suscessfully Updated");
            Con.Close();


        }
        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Rental_Load(object sender, EventArgs e)
        {
            fillcombo();
            fillCustomer();
            populate();
            populate1();
        }

        private void CarRegCb_SelectionChangeCommitted(object sender, EventArgs e)
        {

        }

        private void Custcb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            fetchCustName();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (IdTb.Text == "" || CustNameTb.Text == "" || FeesTb.Text == ""  )
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into RentalTb1 values('" + IdTb.Text + "','" + CarRegCb.SelectedValue.ToString() + "','" + CustNameTb.Text + "', '" + RentDate.Text + "', '" + ReturnDate.Text + "','" + FeesTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Suscessfully Rented");
                    Con.Close();
                    UpadateconRent();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void CustNameTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void FortuneRentDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            IdTb.Text = FortuneRentDGV.SelectedRows[0].Cells[0].Value.ToString();
            CarRegCb.SelectedValue = FortuneRentDGV.SelectedRows[0].Cells[1].Value.ToString();
            FeesTb.Text = FortuneRentDGV.SelectedRows[0].Cells[5].Value.ToString();
        }

        private void RentDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMain main = new FortuneMain();
            main.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (IdTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "Delete From RentalTb1 where Rentid =" + IdTb.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Rental Deleted Suscessfully");
                    Con.Close();
                    populate();
                    UpadateconRentDelete();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void IdTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Mycar_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void CarRegCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void Custcb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void RentDate_ValueChanged_1(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void ReturnDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void FeesTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
       
        
        private void CarDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

            CarRegCb.Text = CarDGV.SelectedRows[0].Cells[0].Value.ToString();
            PriceTb.Text = CarDGV.SelectedRows[0].Cells[4].Value.ToString();
            DateTime d1 = ReturnDate.Value.Date;
            DateTime d2 = RentDate.Value.Date;
            TimeSpan t = d1 - d2;
            int NrOfDays = Convert.ToInt32(t.TotalDays);
            PriceTb.Text = "" + NrOfDays; 
            
            
            
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            e.Graphics.DrawString("FORTUNE CAR RENTAL", new Font("Microsoft Sans Serif", 28, FontStyle.Bold), Brushes.Red, new Point(250, 50));
            e.Graphics.DrawString("NEAR SGM COLLEGE, KARAD ,VIDYANAGAR,KARAD", new Font("Microsoft Sans Serif", 15, FontStyle.Regular), Brushes.Black, new Point(230, 150));
            e.Graphics.DrawString("DATE" + DateTime.Now, new Font("Microsoft Sans Serif", 13, FontStyle.Regular), Brushes.Black, new Point(0, 130));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 170));
            e.Graphics.DrawString("INFORMATION", new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(0, 200));
            e.Graphics.DrawString("CUSTOMER NAME ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(200, 230));
            e.Graphics.DrawString(CustNameTb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(220, 260));
            e.Graphics.DrawString("CAR ID", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(200, 290));
            e.Graphics.DrawString(CarRegCb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(500, 290));
            e.Graphics.DrawString("CUSTOMER ID", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(500, 230));
            e.Graphics.DrawString(Custcb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(520, 260));
            e.Graphics.DrawString("RENT DATE", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(200, 330));
            e.Graphics.DrawString(RentDate.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(200, 360));
            e.Graphics.DrawString("RETURN DATE", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(500, 330));
            e.Graphics.DrawString(ReturnDate.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(520, 360));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 390));
            e.Graphics.DrawString("Amount", new Font("Microsoft Sans Serif", 18, FontStyle.Bold), Brushes.Black, new Point(0, 420));
            e.Graphics.DrawString("TOTAL BILL ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(200, 440));
            e.Graphics.DrawString(FeesTb.Text, new Font("Microsoft Sans Serif", 14, FontStyle.Regular), Brushes.Black, new Point(220, 470));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0,510));
            e.Graphics.DrawString("STAMP ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(150, 960));
            e.Graphics.DrawString("SIGNATURE ", new Font("Microsoft Sans Serif", 15, FontStyle.Bold), Brushes.Black, new Point(600, 960));
            e.Graphics.DrawString("****************************************************************************************************************************************************", new Font("Microsoft Sans Serif", 18, FontStyle.Regular), Brushes.Red, new Point(0, 1000));
         
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            rentalcp rcr = new rentalcp();
            rcr.Show();
        }
    }
}
