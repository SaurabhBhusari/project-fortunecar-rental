﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Fortunecarrental
{
    public partial class FortuneMain : Form
    {
        public FortuneMain()
        {
            InitializeComponent();
        }

        private void gunaCirclePictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneCar car = new FortuneCar();
            car.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneCustomer customer = new FortuneCustomer();
            customer.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneUser user = new FortuneUser();
            user.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Fortunelogin login = new Fortunelogin();
            login.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Rental rental = new Rental();
            rental.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneReturn Return = new FortuneReturn();
            Return.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneDashboard dash = new FortuneDashboard();
            dash.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Hide();
            FORTUNEPROFILE pro = new FORTUNEPROFILE();
            pro.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            Records main = new Records();
            main.Show();
        }
    }
}
