﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class FortuneUser : Form
    {
        public FortuneUser()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

        private void gunaTextBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void populate()
        {
            Con.Open();
            string query = "select * from UserTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FortuneUserDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
  
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Uid.Text == "" || Uname.Text == "" || Upass.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else 
            {
                try 
                {
                    Con.Open();
                    string query = "insert into UserTb1 values("+Uid.Text+",'"+Uname.Text+"', '"+Upass.Text+"')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Suscessfully Added");
                    Con.Close();
                    populate();
                }
                catch(Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FortuneUser_Load(object sender, EventArgs e)
        {
            populate();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (Uid.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else 
            {
                try
                {
                    Con.Open();
                    string query = "Delete From UserTb1 where Id =" + Uid.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Deleted Suscessfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void FortuneUserDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            Uid.Text = FortuneUserDGV.SelectedRows[0].Cells[0].Value.ToString();
            Uname.Text = FortuneUserDGV.SelectedRows[0].Cells[1].Value.ToString();
            Upass.Text = FortuneUserDGV.SelectedRows[0].Cells[2].Value.ToString();
        }
 
        private void button4_Click(object sender, EventArgs e)
        {
            if (Uid.Text == "" || Uname.Text == "" || Upass.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "update UserTb1 set Uname='" + Uname.Text + "',Upass='" + Upass.Text + "'where Id=" + Uid.Text + ";";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("User Suscessfully Updated");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMain main = new FortuneMain();
            main.Show();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            usercrp rcr = new usercrp();
            rcr.Show();
        }
    }
}