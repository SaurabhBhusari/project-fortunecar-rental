﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Fortunecarrental
{
    public partial class returncrp : Form
    {
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");

        public returncrp()
        {
            InitializeComponent();
        }

        private void returncrp_Load(object sender, EventArgs e)
        {
            

       
            DataSet dt = new DataSet();
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select * from ReturnTb1", Con);

            sda.Fill(dt, "ReturnTb1");

           // Con.Close();
            returnCrystalReport2 rcr = new returnCrystalReport2();
            rcr.SetDataSource(dt.Tables["ReturnTb1"]);
            crystalReportViewer1.ReportSource = null;
            crystalReportViewer1.ReportSource = rcr;
            //crystalReportViewer1.Show();
            Con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneReturn Return = new FortuneReturn();
            Return.Show();
        }
    }
}
