﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Fortunecarrental
{
    public partial class FortuneCar : Form
    {
        public FortuneCar()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\Shivam\Documents\Fortunecarrentaldatabase.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
       
        private void populate()
        {
            Con.Open();
            string query = "select * from CarTb1";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FortuneCarDGV.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void FortuneUserDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            RegNo.Text = FortuneCarDGV.SelectedRows[0].Cells[0].Value.ToString();
            BrandTb.Text = FortuneCarDGV.SelectedRows[0].Cells[1].Value.ToString();
            ModelTb.Text = FortuneCarDGV.SelectedRows[0].Cells[2].Value.ToString();
            AvailableCb.SelectedItem = FortuneCarDGV.SelectedRows[0].Cells[3].Value.ToString();
            PriceTb.Text = FortuneCarDGV.SelectedRows[0].Cells[4].Value.ToString();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (RegNo.Text == "" || BrandTb.Text == "" || ModelTb.Text == "" || PriceTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "insert into CarTb1 values('" + RegNo.Text + "','" + BrandTb.Text + "','" + ModelTb.Text + "', '" + AvailableCb.SelectedItem.ToString() + "', '" + PriceTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Suscessfully Added");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

       
            
        

        private void FortuneCar_Load(object sender, EventArgs e)
        {
            populate();
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (RegNo.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "Delete From CarTb1 where RegNo='" + RegNo.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Data Deleted Suscessfully");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (RegNo.Text == "" || BrandTb.Text == "" || ModelTb.Text == "" || PriceTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "update CarTb1 set Brand='" + BrandTb.Text + "',Model='" + ModelTb.Text + "', Available='" + AvailableCb.SelectedItem.ToString() + "' ,Price=" + PriceTb.Text + " where RegNo = '" + RegNo.Text + "';";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Car Data Suscessfully Updated");
                    Con.Close();
                    populate();
                }
                catch (Exception Myex)
                {
                    MessageBox.Show(Myex.Message);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMain main = new FortuneMain();
            main.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            populate(); 
        }
        
            
        private void comboBox1_SelectionChangeCommitted(object sender, EventArgs e)
        {
            string flag = "";
            if (Search.SelectedItem.ToString() == "Available")//Search is name of box.
            {
                flag = "Yes";

            }
            else
            {
                flag = "No";
            }
            Con.Open();
            string query = "select * from CarTb1 where Available = '"+flag+"'";
            SqlDataAdapter da = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            FortuneCarDGV.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void Mycar_Click(object sender, EventArgs e)
        {

        }

        private void MAINTENANCE_Click(object sender, EventArgs e)
        {
            this.Hide();
            FortuneMaintance maint = new FortuneMaintance();
            maint.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            carcrp rcr = new carcrp();
            rcr.Show();
        }
    }
}
